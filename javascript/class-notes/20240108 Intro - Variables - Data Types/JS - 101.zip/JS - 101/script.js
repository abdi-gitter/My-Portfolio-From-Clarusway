// ONE LINE COMMENT

/* 
    Multi
    line
    comment
*/

// explain what you're doing to yourself!

// (ctrl/cmd) and "/" will create a comment

// ES5 syntax:

var a = "es5"

function sayHelloES5(){
    console.log("Hello World!");
}

// ES6 syntax:

const b = "es6"
let b2 = "es6"

const sayHelloES6 = () => {
    console.log("Hello World!");
}



sayHelloES5();
sayHelloES6();