let a = 7
let b = '7'

// console.log(a*b)

console.log('b' + 'a' + + 'a' + 'a')

// console.log()