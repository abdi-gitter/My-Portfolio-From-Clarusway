console.log("Hello World!")

function b(){
    console.log("Function called b!");
}