let a

// Undefined:
console.log(typeof a)

// Null:
// Null is used to indicate that a variable has no value usually intentionally
a = null
console.log(typeof a)

// Numbers:
a = 1
console.log(typeof a)

// Strings:
a = "1"
console.log(typeof a)

// Booleans:
// Boolean values are true and false
a = true
console.log(typeof a)

// Objects:
a = {}
console.log(typeof a)

// Arrays:
a = []
console.log(typeof a)

// NaN:
// NaN stands for Not a Number
a = NaN