// DECLARATION = DEFINITION
var hello = "Hello world!";

console.log(hello)

hello = "Hello world again!";

console.log(hello)

var a = 1

var b = a

a = 16

console.log(b)

var $ = "yes please"
console.log($)