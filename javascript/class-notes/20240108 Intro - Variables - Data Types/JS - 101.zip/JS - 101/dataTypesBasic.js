const a = 7 //number

const b = '7' //string

const c = true //boolean

const d = null //null

const e = undefined //undefined


const obj = 
{
    // properties (variables stored inside an object)
    a: 1,
    b: 2,
    c: 3,

    // methods (functions stored inside an object)
    d: () => {
        console.log('hello')
    }
}

obj.d()

// arrays:

const arr = [1,2,3,4,5]
console.log(arr[0])// reference to an array

console.log(["a","b","c"][0])// This is an array LITERAL


// Be careful when assigning arrays and objects to variables.
// They are passed by reference, not by value.
const arr2 = arr

arr[0] = 100
console.log(arr[0])
console.log(arr2[0])
arr2[4] = 500
console.log(arr[4])

// strings
// using quotes within strings
const str = 'Chase said, "Hello!"'
console.log(str)

const str2 = "Chase said, 'Hello!'"
console.log(str2)

// escaping quotes within strings
let str3 = 0
console.log(str3)

const bool1 = true
console.log(Boolean(bool1))

console.log(Boolean(str3))

if(!str3){
    str3 = "Hello World!"
}

console.log(str3)
console.log(Boolean(str3))

if(str3){console.log('Do something')}
