// Const
// Immutable! - Cannot be changed/mutated
const PI = 3.1415;
// PI = 3.14;
console.log(PI);

// let
// I only exists inside the scope of the for loop
for(let i = 0 ; i < 5 ; i++){
    console.log(i+1);
}
// This causes an error:
// console.log(i)

console.log('------------------');

// var
console.log(j);

for(var j = 0 ; j < 5 ; j++){
    console.log(j+1);
}
// This does not cause an error:
// This is because var is not block scoped, it is function scoped
console.log(j);

// With let and var, we can assign values after declaring the variable

let k
var l

k = 1
l = 1

console.log(k)
console.log(l)