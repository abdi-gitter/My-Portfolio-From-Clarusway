const num1 = 7//number
const num2 = '7'//string

// With addition of a string and number, the number is converted to a string
console.log(num1 + num2)

// concatination of strings:
console.log('hello' + ' world')

console.log(7+7)
console.log('7'+'7')