// conversion and coercion:

// conversion: explicit conversion
var a = "42";
var b = Number(a);
console.log(a); // "42"
console.log(b); // 42

// coercion: implicit conversion
var a = "42";
var b = a * 1; // "42" implicitly coerced to 42 here

console.log(a); // "42"
console.log(b); // 42

console.log(a-1);

console.log("Hello " + "World" + "!")

let x = 12
let y = "12"

console.log(x + Number(y)) // 24
console.log(x + y) // 1212
console.log(x + parseInt(y)) // 24
console.log(x + parseFloat(y)) // 24
console.log(x + +y) // 24

// ALL USER INPUT IS A STRING