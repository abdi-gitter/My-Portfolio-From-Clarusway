const person1 = 31
const person2 = 42
const person3 = 47
const person4 = 22
const person5 = 19

// Check if person 2 and person 3 are both between ages of 40 and 50:
if(( person2 >= 40 && person2 <= 50 ) && ( person3 >= 40 && person3 <= 50 )){
    console.log("CONDITION TRUE")
} else{
    console.log("CONTIDION FALSE")
}

// check to see if person4 is equal to or less than half of person3
if(person4 <= person3 / 2){
    console.log("person 3 is more than twice the age of person 4!")
}else{
    console.log("person 4 is not younger than half the age of person 3.")
}