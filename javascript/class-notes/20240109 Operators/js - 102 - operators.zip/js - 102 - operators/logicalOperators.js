// logical operators:

// && logical AND operator
// This returns true if BOTH operands are true.
console.log(true&&true)//>> true
console.log(true&&false)//>> false
console.log(false&&true)//>> false

// || logical OR operator
// This returns true if EITHER operand is true.
console.log(true||true)//>> true
console.log(true||false)//>> true
console.log(false||true)//>> true

// ! logical NOT operator
// This returns the opposite of the operand.
console.log(!true)//>> false
console.log(!false)//>> true
console.log(!(3>4))//>> true

// && and || are short-circuit operators.
// This means that if the first operand is true, it will return the second operand.
// If the first operand is false, it will return the first operand.
console.log(3&&4)//>> 4
console.log(3||4)//>> 3
console.log(0&&4)//>> 0
console.log(0||4)//>> 4