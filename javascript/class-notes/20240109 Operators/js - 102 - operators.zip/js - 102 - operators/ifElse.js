const number = 4

if (number>=5){
    console.log("number is greater than or equal to 5")
} else if(number>=4){
    console.log("number is greater than or equal to 4")
} else if(number>=3){
    console.log("number is greater than or equal to 3")
} else if(number>=2){
    console.log("number is greater than or equal to 2")
} else if(number>=1){
    console.log("number is greater than or equal to 1")
} else{
    console.log("number is larger than 5 or smaller than 1")
}