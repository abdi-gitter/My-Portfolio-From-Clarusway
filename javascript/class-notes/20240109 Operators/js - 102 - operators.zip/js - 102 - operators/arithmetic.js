// Math operators:
/* 
    +  (addition)
    -  (subtraction)
    *  (multiplication)
    /  (division)

    %  (modulus) - remainder of division
    ++ (increment) - adds 1 to the value of a variable
    -- (decrement) - subtracts 1 from the value of a variable
    ** (exponentiation) - raises a number to a power
*/

// Basic math operators:
console.log(7+7) //>> 14
console.log(7-7) //>> 0
console.log(7*7) //>> 49
console.log(7/7) //>> 1

// Modulus operator:
// The modulus operator returns the remainder of a division operation.
// It is represented by the % symbol.
// If the number is even, the remainder will be 0.
// If the number is odd, the remainder will be 1.
// The modulus operator is useful for determining if a number is even or odd.
console.log("MODULUS OPERATOR: ")
// 7 can go in to 100 14 times, until there's 2 left.
console.log(100 % 7)
// 7/2 = 3.5
// 7%2 = 1
// 2 goes in to 7 three times, with 1 left over.

// Custom function to calculate modulus:
function modulo(num1,num2){
    console.log(num1 + " % " + num2 + " is :")
    for(let i = num1; i > 0; i=i-num2){
        if(i<num2){
            console.log("remainder: " + i)
            break
        }
        // console.log(i)
    }
}
// calling our custom function:
modulo(100,7)

// increment and decrement operators:

// increment operator:
let num = 0
console.log("increment operator: ")
console.log(num) //>> 0
num = num + 1
console.log(num) //>> 1
// shorthand increment operator:
num++ // adds 1 to the value of num
console.log(num) //>> 2

// decrement operator:
console.log("decrement operator: ")
num = 0;
console.log(num) //>> 0
num = num - 1
console.log(num) //>> -1
// shorthand decrement operator:
num-- // subtracts 1 from the value of num
console.log(num) //>> -2

// exponentiation operator:
console.log("exponentiation operator: ")
// 2^3 = 8 or 2*2*2 or 2 to the power of 3
console.log(2**3) //>> 8

// WEIRD BITS:
console.log('WEIRD BITS!')
console.log('-----------')
let a = 0
// when I try to perform the operation inside of a console log, it's going to log the value of a BEFORE the operation is performed.
console.log(a++) //>> 0
console.log(a) //>> 1
// putting the operation BEFORE the variable will perform the operation BEFORE the console log.
console.log(++a)// >> 2
console.log("This works for incrementing and decrementing.")

console.log(1+2*(5-4/2)**2) // >> 19

// Order of operations:
// PEMDAS
// Parentheses
// Exponents
// Multiplication
// Division
// Addition
// Subtraction
