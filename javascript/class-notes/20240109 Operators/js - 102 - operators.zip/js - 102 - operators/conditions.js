const chase = 19
const abdisa = 22
const jacek = 16
const ahmed = 27
const birsen = 15

function ageCheck(person){
    // let person = WHATEVER IS PASSED
    console.log("You are " + person + " years old.")
    if(person>=21){
        console.log("You can drink!")
    } else if(person>=18){
        console.log("You can vote!")
    } else if(person>=16){
        console.log("You can drive!")
    } else{
        console.log("You can't do anything.")
    }
}

ageCheck(chase)
ageCheck(abdisa)
ageCheck(jacek)
ageCheck(ahmed)
ageCheck(birsen)

const jacek2 = {
    name: "Jacek",
    age: 18,
    admin: false
}

if(jacek2.admin===false && jacek2.age>=18 || jacek2.name==="Jacek"){
    console.log("Jacek is an admin!")
}else{
    console.log("Jacek is not an official admin... YET")
}