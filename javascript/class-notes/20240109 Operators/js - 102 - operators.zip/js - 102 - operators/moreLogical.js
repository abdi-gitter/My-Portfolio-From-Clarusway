const drinks = false
const smokes = false

if (drinks === true && smokes === true) {
    console.log("You're a party animal!")
} else if (drinks===true || smokes===true) {
    console.log("You're a bit of a party animal!")
} else {
    console.log("You're no fun!")
}