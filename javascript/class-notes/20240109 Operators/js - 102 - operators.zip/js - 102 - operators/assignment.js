// Assignment operators:
let a;

// = assignment operator
a = 0;

// += addition assignment operator
// we want a to be equal to a plus SOMETHING:
a += 5; // a = a + 5
console.log(a); //>> 6

// reset a:
a = 0;

// -= subtraction assignment operator
// we want a to be equal to a minus SOMETHING:
a -= 5; // a = a - 5
console.log(a); //>> -5

// reset a:
a = 0;

// *= multiplication assignment operator
// we want a to be equal to a times SOMETHING:
a *= 5; // a = a * 5
console.log(a); //>> 0

// reset a:
a = 0;
// /= division assignment operator
// we want a to be equal to a divided by SOMETHING:
a /= 5; // a = a / 5
console.log(a); //>> 0

// reset a:
a = 34;

// %= modulus assignment operator
// we want a to be equal to a modulus SOMETHING:
a %= 5; // a = a % 5
console.log(a); //>> 4

// reset a:
a = 2;

// **= exponentiation assignment operator
// we want a to be equal to a to the power of SOMETHING:
a **= 5; // a = a ** 5
console.log(a); //>> 32