// comparison operators:
let myBool = true
myBool = false

// Assigning a value to an expression:
myBool = 3=="3" //>> true
myBool = 3*3//>> 9

// == equality operator
// This will compare the value, not the type.
console.log(3==3)//>> true
console.log(3=='3')//>> true

// === strict equality operator
// This will compare the value AND the type.
console.log(3===3)//>> true
console.log(3==='3')//>> false

// != inequality operator
// This will return true if the values are NOT equal.
console.log(3!=3)//>> false
console.log(3!='3')//>> false
console.log(3!=4)//>> true

// !== strict inequality operator
// This will return true if the values are NOT equal AND NOT the same type.
console.log(3!==3)//>> false
console.log(3!=='3')//>> true
console.log(3!==4)//>> true

// > greater than operator
// This returns true if the value on the left is greater than the value on the right.
console.log(3>3)//>> false
console.log(3>2)//>> true
console.log(3>4)//>> false

// >= greater than or equal to operator
// This returns true if the value on the left is greater than or equal to the value on the right.
console.log(3>=3)//>> true
console.log(3>=2)//>> true
console.log(3>=4)//>> false

// < less than operator
// This returns true if the value on the left is less than the value on the right.
console.log(3<3)//>> false
console.log(3<2)//>> false
console.log(3<4)//>> true

// <= less than or equal to operator
// This returns true if the value on the left is less than or equal to the value on the right.
console.log(3<=3)//>> true
console.log(3<=2)//>> false
console.log(3<=4)//>> true