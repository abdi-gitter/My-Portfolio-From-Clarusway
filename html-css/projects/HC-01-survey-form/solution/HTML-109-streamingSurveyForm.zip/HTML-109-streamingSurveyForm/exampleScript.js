const responseOBJ = {
    data:{
        name: "John Doe",
        age: 20,
        email: "johnDoe@email.com"
    },
    status: 200
}

const responseOBJ2 = {
    data:{
        name: "Jane Doe",
        age: 27,
        email: "janeDoe@email.com"
    },
    status: 400
}

function makeElement(resObj){
    const {data: {name, age, email}, status} = resObj;

    const container = document.querySelector("#container");

    container.innerHTML += `
        <div class="card">
            <h1 class="name">${name}</h1>
            <p class="age">${age}</p>
            <p class="email">${email}</p>
            <p class="status">Satus Code: ${status}</p>
        </div>
    `
}

makeElement(responseOBJ);
makeElement(responseOBJ2);